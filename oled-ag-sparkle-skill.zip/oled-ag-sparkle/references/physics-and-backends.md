# 屏幕点亮随机 AG 闪点：多后端基准项目

输入为 `heightfield.png`（AG 实测表面高度）、`emission.png`（OLED 亮度分布），包含各自的 **µm/图像像素**、高度范围（黑→白对应的 µm）以及 OLED→AG 平均高度。统一生成二维光强、flat-AG 参考和参考归一化闪点统计。所有后端使用**固定求积、不引入 Monte Carlo 随机采样噪声**。

## 计算后端

| `--backend` | 求解方法 | 真正调用的第三方核心 | 物理相位 | 是否与 Torch 数值比较 |
|---|---|---|---|---|
| `torch` | 标量角谱传播 ASM；薄相位屏；理想光瞳 | PyTorch FFT | ✅ | 基线 |
| `torchoptics` | 同一标量模型 | `torchoptics.Field.propagate_to_z(..., ASM)` 求点源传播核；PyTorch FFT 完成后续成像 | ✅ | 可以，应数值接近 |
| `chromatix` | 同一标量模型 | `chromatix.functional.asm_propagate` 求点源传播核；JAX FFT 完成后续成像 | ✅ | 可以，应数值接近 |
| `mitsuba` | 几何折射模型、固定 pupil 方向积分 | `mitsuba.Mesh`、`scene.ray_intersect`；解析 Snell + Fresnel | ❌ | **不同物理模型**，比较趋势而非逐像素强制一致 |

**注意**：`mitsuba` 后端不是 `mi.render()` 的随机路径追迹，而是用 Mitsuba 3 做**真实高度网格求交**，再通过固定光瞳节点的确定性折射与 OLED 纹理查表得到传感器强度。这避免了 MC 噪声，但**没有衍射、相位或镜头 PSF**。因此物理模型不同造成的数值差异并非代码错误。

`torchoptics`/`chromatix` 后端并非把用户的所有输入交给对应库「自动计算闪点」；它们利用各自的波动传播算子，项目自行完成 OLED 模式积分与相机光瞳。完整实现详见源码。

## 安装

推荐 Python 3.11+，在虚拟环境中安装。先安装合适的 GPU/CUDA PyTorch 和 JAX（按系统对应官方指引），再根据所需后端安装对应库。

```bash
uv pip install numpy pillow torch
uv pip install torchoptics          # TorchOptics 后端
uv pip install chromatix            # Chromatix 后端；GPU 还需配置 JAX CUDA
uv pip install mitsuba              # Mitsuba 3 后端
```

Mitsuba CUDA 需要可用的 OptiX/CUDA 运行环境与支持的 GPU；CPU 可尝试 `llvm_ad_rgb`。Chromatix/JAX GPU 版本和 CUDA 组合需按 JAX 官方安装说明选取（不是安装 PyTorch CUDA 就自动启用 JAX CUDA）。

官方文档：
- TorchOptics: https://torchoptics.readthedocs.io/en/latest/user-guide/propagation.html
- Chromatix: https://chromatix.readthedocs.io/en/latest/api/functional/
- Mitsuba mesh: https://mitsuba.readthedocs.io/en/latest/src/how_to_guides/mesh_io_and_manipulation.html

## 实际 1×1 mm、0.5 µm / 图像像素示例

假设 Height Field 为 2000²，亮度分布 `emission.png` 每个图像像素代表 50 µm（若它是 5 µm / image pixel 则必须写 5，**与显示器 Pixel Pitch 可以不同**），高度图灰度全范围代表 2 µm 的物理高度变化。

```bash
python sparkle_multibackend.py \
  --height heightfield.png --height-pitch-um 0.5 --height-range-um 2 \
  --emission emission.png --emission-pitch-um 50 \
  --analysis-pitch-um 50 \
  --gap-um 500 --wavelength-nm 530 \
  --n-stack 1.50 --n-out 1.0 --na 0.08 \
  --source-samples 1 --pad-px 192 --batch 2 \
  --roi-margin-um 100 --device cuda \
  --backend all --out results
```

- `--height-pitch-um`：AG 图中每个像素对应的**横向长度**；`--height-range-um`：高度灰度黑至白对应的**竖向高度差**。
- `--emission-pitch-um`：Emission 图中每个 texel 的横向长度（不是显示屏单元间距）；`--analysis-pitch-um`：统计时每个显示单元的 pitch。
- `--gap-um`：OLED 发光面→AG 平均表面的距离；当前以均匀有效介质 `n-stack` 代替真实多层 OCA/玻璃。
- `--na`：理想相机物侧数值孔径；不包含真实相机像差和传感器 MTF。
- `--source-samples`：每个亮的 emission texel 每轴 K 个固定的独立非相干模式，模式总数约 `#亮texel × K²`。`1` 只做快速测试。提高到 2、4 做收敛检查。
- `--pad-px`：波传播 FFT 的每侧 padding；应进行 padding 收敛测试。
- `--ray-radial 3 --ray-angular 8`：Mitsuba 的 24 个固定光瞳求积方向。可增加到 `6×16` 检查收敛。
- `--mesh-stride 1`：Mitsuba 使用原始高度采样建网格；2000² 高度图约 400 万顶点、800 万三角形，建网格内存可观。可用 `--mesh-stride 2` 降低显存压力，但**改变了 AG 几何，严谨的波/射线对比需用同等几何分辨率**。
- `--emission-channel green`：绿色显示若只有 G 通道亮，可以明确选取；PNG RGB 按输入相对线性发光强度处理。若是普通 sRGB 图片，请加 `--gamma-decode`。

安装部分后端时，可以先：

```bash
python sparkle_multibackend.py ... --backend all --skip-unavailable
```

只会跳过确实缺少依赖的后端；其他计算错误不会被静默跳过。也可以用 `--backend torch`、`--backend chromatix`、`--backend mitsuba` 分别单独跑。

### 小规模 CPU 示例（包中自带合成输入）

```bash
python sparkle_multibackend.py \
  --height demo/heightfield.png --height-pitch-um 2 --height-range-um 0.5 \
  --emission demo/emission.png --emission-pitch-um 64 \
  --gap-um 500 --analysis-pitch-um 64 --roi-margin-um 0 \
  --pad-px 64 --batch 2 --device cpu --backend torch --out demo_result
```

再将 `demo/heightfield.png` 替换为 `demo/height_flat.png`，应获得接近 0 的参考归一化 CV。使用包中合成随机表面，已在 PyTorch CPU 上实测约 **3.26972%**；平面测试约 **0.00001%**。合成数据没有任何实际玻璃/仪器标定意义。

## 文件输出

- `results/torch/`、`results/torchoptics/`、`results/chromatix/`、`results/mitsuba/`：每个后端输出相同布局。
- `intensity_ag.npy` / `.png`：AG 亮度场。
- `intensity_flat.npy` / `.png`：平坦 AG 参考亮度场。
- `cell_ag.npy`, `cell_flat.npy`：按显示像素单元区域积分后的强度。
- `cell_ratio.npy`：各显示单元 `P_AG / P_flat`，无效单元为 NaN。
- `valid_cell_mask.npy`：共同定义的 ROI 内且参考信号充足的有效单元。
- `stats.json`：波长、尺寸、后端、运行时间、PPD-like CV 与限制。
- `comparison.csv` / `comparison.json`：各后端总表、配对 `cell_ratio` MAE / RMSE，以及是否属于相同物理模型。**请勿仅按绝对 CV 差异评估 Mitsuba 与波动光学实现优劣。**

本原型用的非标准指标为：

```text
R_ij = sum_AG(i,j) / sum_flat(i,j)
Sparkle_like = std(R_valid) / mean(R_valid)
```

先对各显示单元积分，排除低信号单元和边界，再统计。它并不是 IEC 62977-3-9 的标准相机输出数字。脚本没有以 `sum AG / sum flat` 的全场平均作为相机曝光模拟；默认相对亮度就足够做 CV。

## 规模/物理注意事项

1. **不是整个 8×8 mm 实测 ROI 的预测**。单张 1×1 mm Height Field 只能给出局部、在统计平稳假设下可能具有代表性的结果；建议采集多个独立 AG 位置估计区间。
2. 2000² + pad192 -> 2384² 的 FFT，每个 complex64 场约 43.4 MiB。完整波模型还需多个缓冲、批量 FFT 和重复模式求解；400 个 emission texel × `source-samples=4`² = **6400 个模式**，会很慢，建议从 K=1 / 2 开始做收敛。
3. Mitsuba 2000² 高度图 Mesh 约 8M triangles；默认 3×8 = 24 个 pupil 方向、2000² 个像素 → **约 9600 万个确定性求交射线**。大型算例应使用 NVIDIA GPU，并按实际内存调节 `--mesh-stride` 和 `--ray-chunk`。角分布积分收敛同样需要检查。
4. 波模型用薄相位屏 `exp(i 2π (n_stack-n_out) (h-mean(h))/λ)`，**不是**真实 AG 三维 Maxwells 求解；未考虑高斜率表面严格电磁边界、纳米结构、偏振以及实际多层结构。几何模型使用表面法向 + 斯涅尔定律，没有相位。
5. 波模型的固定相干模式对应点源理想化；一般 OLED 有有限发光面积、角分布和有限相干性。必须检查模式密度、绿光谱宽度、相机光圈/MTF、pad 和外边界对结果的影响。
6. **没有 Monte Carlo 噪声 ≠ 一定精确**。网格离散、FFT 周期边界、有限相干模式、随机玻璃样本不足、相机校准误差仍可主导结果。

## 验证状态（本包制备环境）

- ✅ `torch` 实际运行成功：平面 AG、合成随机 AG 回归测试。
- ✅ `all --skip-unavailable` 实际测试成功：已安装 backend 写入比较文件，缺失依赖在 `errors.json` 中清晰标记。
- ⚠️ `torchoptics`、`chromatix`、`mitsuba`：已按当前官方 API 文档实现，但制备环境未装这些包、也无法联网安装，所以**尚未实机跑通**。请不要把它们视为已验证生产级实现；用户环境运行如有异常，应依据具体库版本修正兼容性。

建议先在小规模 demo 上用 `--backend all` 完成三套波动后端数值对齐，再运行真实 2000² 实测数据。
