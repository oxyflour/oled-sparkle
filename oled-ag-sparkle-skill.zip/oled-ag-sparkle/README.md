# OLED AG Sparkle — multi-backend Agent Skill

A self-contained reusable **Agent Skill** for display-on sparkle simulations. It packages the previous four-backend solver plus small and 1 mm physical-scale synthetic PNG inputs.

## Installation

Extract this folder without changing the internal structure:

- Codex / agents with project skills: `<project>/.agents/skills/oled-ag-sparkle/`
- Claude Code: `<project>/.claude/skills/oled-ag-sparkle/` (if this skills layout is supported by your client)
- Or keep as a standalone folder, read `SKILL.md`, and run the CLI directly.

`SKILL.md` contains instructions for an agent; the Python scripts and PNGs are fully included locally. No plugin/connector is required for the ZIP itself.

## Install Python dependencies

```bash
uv pip install -r requirements-core.txt
# Install only the optional backends you want to test:
uv pip install torchoptics
uv pip install chromatix
uv pip install mitsuba
```

For CUDA: choose PyTorch/JAX wheels suitable for your OS, GPU and CUDA version. On Windows, use `py -3.11` instead of `python` if appropriate.

## Test the small sample immediately

```bash
python scripts/run_demo.py --backend torch
python -m unittest discover -s tests -v
```

For an installed group of backends:

```bash
python scripts/run_demo.py --backend all --skip-unavailable
```

Results will be under `outputs/demo_quick/` by default. Missing optional backends are recorded in `errors.json`.

## 1×1 mm example, exactly matching requested physical dimensions

- `assets/demo_1mm/heightfield.png`: **2000×2000, 16-bit grayscale, 0.5 µm/pixel**; black/white represents 2 µm of height.
- `assets/demo_1mm/emission.png`: **20×20 RGB, 50 µm/texel**, 20×20 green-on display pixels.
- `assets/demo_1mm/emission_subpixel.png`: **100×100 RGB, 10 µm/texel**, simplified green subpixel apertures inside the 50 µm display pixel cells.
- `assets/demo_1mm/height_flat.png`: identical 2000×2000 flat-height control.

**These are synthetic test images, not AG measurements or a physically calibrated OLED emission profile.**

Check source count, FFT array and ray cost without running:

```bash
python scripts/run_demo.py --example 1mm --backend all --dry-run
```

To run the 1 mm sample (can be significantly slower than tiny demo):

```bash
python scripts/run_demo.py --example 1mm --backend torch --device cuda --out outputs/demo_1mm
```

With detailed emission, source count is higher:

```bash
python scripts/run_demo.py --example 1mm --emission-variant subpixel --backend torch --dry-run
```

Direct real-data example:

```bash
python scripts/sparkle_multibackend.py \
  --height /path/to/heightfield.png --height-pitch-um 0.5 --height-range-um 2 \
  --emission /path/to/emission.png --emission-pitch-um 10 \
  --analysis-pitch-um 50 --gap-um 500 \
  --wavelength-nm 530 --n-stack 1.5 --n-out 1 --na 0.08 \
  --backend all --skip-unavailable --device cuda --out outputs/real
```

In Windows PowerShell use **one command line** or replace Bash line-continuation `\` with PowerShell backtick.

## Output and limitations

See `references/physics-and-backends.md` for the model, output naming and limitations. Important: the metric is `std(cell_ag/cell_flat)/mean(cell_ag/cell_flat)` after a common ROI mask; this is a research **PPD-like** statistic, NOT certified IEC 62977-3-9 sparkle contrast. The 1mm demo is for reproducibility and input scale checks only.

Verification performed during packaging: `torch` regression and the supplied quick demo. The other three solver adapters are not executable in this environment without their dependencies and remain **unverified** until run on your machine.
