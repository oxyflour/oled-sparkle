---
name: oled-ag-sparkle
description: Simulate illuminated OLED/LCD display sparkle from a measured AG heightfield PNG and emission PNG, using interchangeable PyTorch FFT, TorchOptics, Chromatix and Mitsuba backends; run fixed-input comparisons and report numerical convergence and physical limitations.
---

# OLED AG sparkle simulation

## When to use

Use this skill when the user provides an AG random surface `heightfield.png` and an illuminated pixel pattern `emission.png`, or asks to predict or compare display sparkle caused by AG surface morphology, OCA/glass spacing, camera NA, diffraction, or geometry. Prefer this skill for **display-on** sparkle, not externally reflected glare.

## Essential inputs

- Height image path (grayscale 8/16-bit PNG), horizontal sampling pitch in **µm/image texel**, and total physical height mapping from black to white in **µm**.
- Emission image path (RGB PNG), its **µm/image texel**; note: this is NOT necessarily the panel display-pixel pitch.
- Display-cell pitch for PPD-like statistics, OLED to mean AG distance, refractive indices, wavelength, and camera object-space NA.

Ask only for genuinely missing physical inputs if they cannot be estimated; clearly identify any assumptions. NEVER conflate image texel pitch with display pixel pitch or height range with OLED-to-AG separation.

## Workflow

1. Start in this skill directory (`SKILL.md` parent). Read `assets/*/metadata.json` to understand supplied examples.
2. Confirm image geometry and source mode count before large calculations using `--dry-run`, especially at 2000×2000 or for large emission bitmaps.
3. Run `torch` on the small quick demo to verify dependencies and expected outputs. See `scripts/run_demo.py` and `README.md`.
4. Prefer comparing `torch`, `torchoptics` and `chromatix` for numerical consistency of a **scalar ASM + thin phase-screen** wave model. `mitsuba` is a **different geometry/ray** model, based on explicit height mesh + fixed pupil-angle quadrature; it has no phase or diffraction. Do not demand per-pixel agreement with wave backends.
5. Keep height field, emission, wavelength, area, padding, ROI and postprocessing identical across backends; record software versions and settings. Compare `comparison.csv`, `comparison.json`, `stats.json`, `cell_ratio.npy`, and visual intensity images.
6. Validate convergence: increase `--source-samples`, `--pad-px`, optical grid density, pupil nodes (`--ray-radial`, `--ray-angular`) and ROI margin; do not claim physical accuracy without measured camera/AG comparison.
7. Describe output as **reference-normalized PPD-like CV**, not IEC 62977-3-9 certified Sparkle Contrast. A 1×1 mm AG tile cannot reproduce spatial positions within an actual 8×8 mm measurement ROI; statistical extrapolation needs multiple representative tiles.

## Quick run

```bash
python scripts/run_demo.py --backend torch
```

Compare installed backends (skip missing optional dependencies):

```bash
python scripts/run_demo.py --backend all --skip-unavailable
```

Size check of the supplied **1×1 mm, 0.5 µm** synthetic dataset (no computation):

```bash
python scripts/run_demo.py --example 1mm --backend all --dry-run
```

For real files use `python scripts/sparkle_multibackend.py --help`, then supply `--height`, `--height-pitch-um`, `--height-range-um`, `--emission`, `--emission-pitch-um` and the optical model parameters. See `README.md` for complete commands and Windows examples.

## Backend support and uncertainty

| backend | core library | physics | validation |
| --- | --- | --- | --- |
| `torch` | PyTorch FFT | scalar wave / thin phase screen | executed on synthetic regression samples |
| `torchoptics` | TorchOptics propagation kernel + PyTorch imaging | same scalar wave | adapter written, **not run** in supplied environment |
| `chromatix` | Chromatix propagation kernel + JAX imaging | same scalar wave | adapter written, **not run** in supplied environment |
| `mitsuba` | Mitsuba mesh intersections + deterministic Snell quadrature | geometric rays (no diffraction) | adapter written, **not run** in supplied environment |

Don't report that optional adapters passed runtime verification until they really run successfully in the target environment. Fix version-specific API differences if needed; preserve common inputs and output contract. No Monte Carlo shot sampling is used in the supplied algorithms; discretization, pupil quadrature, FFT padding, finite independent source modes, and optical-model approximations still cause errors.

## Files

- `scripts/sparkle_multibackend.py`: main unified CLI solver.
- `scripts/run_demo.py`: working directory-independent demo/dry-run wrapper.
- `assets/demo_quick/`: small 128×128 AG height and 4×4 emission for an actual CPU run.
- `assets/demo_1mm/`: synthetic 2000×2000 height (0.5 µm per texel) and 20×20 green emission (50 µm per texel), plus a finer subpixel emission bitmap.
- `tests/test_smoke.py`: baseline regression tests.
- `references/physics-and-backends.md`: in-depth model assumptions, installation and limitations.

Always include the code/output paths and a clear statement of which backends were actually executed and which were unavailable.
