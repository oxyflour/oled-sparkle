"""Dependency-free unittest smoke tests for the native torch reference backend."""
from __future__ import annotations
import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path
import numpy as np
from PIL import Image

SCRIPT=Path(__file__).resolve().parents[1]/'sparkle_multibackend.py'


class SmokeTest(unittest.TestCase):
    def run_sample(self,flat=False):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d)
            rng=np.random.default_rng(44)
            h=np.full((128,128),128,dtype=np.uint8)
            if not flat:
                h=np.clip(128+25*rng.standard_normal((128,128)),0,255).astype(np.uint8)
            em=np.full((4,4,3),255,dtype=np.uint8)
            Image.fromarray(h).save(root/'heightfield.png')
            Image.fromarray(em).save(root/'emission.png')
            cmd=[sys.executable,str(SCRIPT),'--height',str(root/'heightfield.png'),
                 '--height-pitch-um','2','--height-range-um','0.5',
                 '--emission',str(root/'emission.png'),'--emission-pitch-um','64',
                 '--analysis-pitch-um','64','--gap-um','500','--pad-px','64',
                 '--roi-margin-um','0','--backend','torch','--device','cpu',
                 '--progress-every','0','--out',str(root/'results')]
            subprocess.run(cmd,check=True,capture_output=True,text=True)
            stats=json.loads((root/'results'/'torch'/'stats.json').read_text())
            for f in ['intensity_ag.npy','intensity_flat.npy','cell_ratio.npy','valid_cell_mask.npy']:
                self.assertTrue((root/'results'/'torch'/f).exists())
            self.assertEqual(np.load(root/'results'/'torch'/'intensity_ag.npy').shape,(128,128))
            return stats['reference_normalized_cv_percent']

    def test_flat_is_zero(self):
        self.assertLess(self.run_sample(flat=True),0.001)

    def test_random_is_nonzero(self):
        self.assertGreater(self.run_sample(flat=False),0.01)


if __name__=='__main__':
    unittest.main()
