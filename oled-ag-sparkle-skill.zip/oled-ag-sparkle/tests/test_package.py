from pathlib import Path
import json
import unittest
import numpy as np
from PIL import Image

ROOT=Path(__file__).resolve().parents[1]

class PackageAssetsTest(unittest.TestCase):
    def test_skill_header_and_scripts(self):
        content=(ROOT/'SKILL.md').read_text(encoding='utf-8')
        self.assertIn('name: oled-ag-sparkle',content)
        self.assertTrue((ROOT/'scripts/run_demo.py').is_file())
        self.assertTrue((ROOT/'scripts/sparkle_multibackend.py').is_file())

    def test_1mm_geometry_and_encoding(self):
        base=ROOT/'assets/demo_1mm'
        meta=json.loads((base/'metadata.json').read_text(encoding='utf-8'))
        h=np.array(Image.open(base/'heightfield.png'))
        self.assertEqual(h.shape,(2000,2000))
        self.assertEqual(h.dtype,np.uint16)
        self.assertAlmostEqual(h.shape[0]*meta['heightfield']['image_pitch_um']/1000,1.0)
        em=np.array(Image.open(base/'emission.png'))
        self.assertEqual(em.shape,(20,20,3))
        self.assertEqual(em[...,1].sum(),20*20*255)
        detail=np.array(Image.open(base/'emission_subpixel.png'))
        self.assertEqual(detail.shape,(100,100,3))

if __name__=='__main__': unittest.main()
